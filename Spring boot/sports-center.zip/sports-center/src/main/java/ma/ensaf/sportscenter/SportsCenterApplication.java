package ma.ensaf.sportscenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsCenterApplication.class, args);
	}

}
